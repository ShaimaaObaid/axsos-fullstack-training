const button = document.querySelector(".hero_button")
button.addEventListener("mouseover",function(){
    button.style.backgroundColor="#3b4598"
})
button.addEventListener("mouseout",function(){
    button.style.backgroundColor=""
})
const changeButton =document.querySelector(".about-button")
const changeImg =document.querySelector(".about_img")
let isChanged = false
changeButton.addEventListener("click",function(){
   if(!isChanged){
     changeButton.innerText="Change Back"
    changeImg.src="static/alt-features.png"
    isChanged =true
   }
   else{
    changeButton.innerText="Make A Change"
    changeImg.src="static/about.jpg"
    isChanged =false
   }
    

})
/*
const addButton =document.querySelector(".add-service")
const container=document.querySelector(".service")
let count= container.children.length +1
addButton.addEventListener("click",function(){
    const newCard=document.createElement("div")
    newCard.classList.add("service")
    const newImg=document.createElement("img")
    newImg.src="static/features.png"
    newImg.width=150;
    const newText=document.createElement("p")
    newText.innerText="lorem loremlorem"+count
    newCard.appendChild(img)
    newText.appendChild(p)
    container.appendChild(newCard)
    count++;
})*/
document.addEventListener("DOMContentLoaded",function(){
    const addButton =document.querySelector(".add-service")
    const section=document.querySelector(".three_services_sec")
    let count= section.children.length +1
    addButton.addEventListener("click",function(){
const newCard=document.createElement("div")
    newCard.classList.add("service")
    const newImg=document.createElement("img")
    newImg.src="static/features.png"
    newImg.width=150;
    const newText=document.createElement("p")
    newText.innerText="lorem loremlorem"+count
    newCard.appendChild(img)
    newText.appendChild(p)
    section.appendChild(newCard)
    count++

    })


})

